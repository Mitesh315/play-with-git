package com.task.userCrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
