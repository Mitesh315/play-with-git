package com.emp.empManagementSys;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpManagementSysApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpManagementSysApplication.class, args);
	}

}
