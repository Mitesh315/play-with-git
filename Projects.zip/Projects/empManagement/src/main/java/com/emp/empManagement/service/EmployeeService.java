package com.emp.empManagement.service;

import java.util.List;
import java.util.Optional;

import com.emp.empManagement.dto.EmployeeDto;
import com.emp.empManagement.model.Employee;

public interface EmployeeService {

	void addEmp(EmployeeDto request);
	List<Employee> findAll();
	Optional<Employee> findById(long id);
	int updateEmp(long id, EmployeeDto request);
	void deletEmp(long id);
}
