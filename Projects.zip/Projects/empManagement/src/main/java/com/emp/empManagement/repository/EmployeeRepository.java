package com.emp.empManagement.repository;

import java.util.List;
import java.util.Optional;

import com.emp.empManagement.dto.EmployeeDto;
import com.emp.empManagement.model.Employee;

public interface EmployeeRepository {

	List<Employee> findAll();
	void addEmp(EmployeeDto employeeDto);
	int updateEmp(long id, EmployeeDto request);
	Optional<Employee> findById(long id);
	void deleteEmp(long id);
}
