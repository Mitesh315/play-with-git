package com.task.UserDashboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserDashboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
