package com.task.UserDashboard.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.task.UserDashboard.dto.User;

@Repository
public class UserRepositoryImpl implements UserRepository{

	private final JdbcTemplate jdbcTemplate;
	
	public UserRepositoryImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	@Override
	public List<User> findAll() {
		String sql = "SELECT * from user";
		return jdbcTemplate.query(sql, new UserRowMapper());
	}

	@Override
	public void save(User user) {
		String sql = "INSERT INTO user (id, name, mobile, dept_name) VALUES (?, ?, ?, ?)";
		jdbcTemplate.update(sql, user.getId(), user.getName(), user.getMobile(), user.getDeptName());
	}
	
	private static class UserRowMapper implements RowMapper<User> {
		@Override
		public User mapRow(ResultSet resultSet, int rowNum) throws SQLException {
			User user = new User();
			user.setId(resultSet.getLong("id"));
			user.setName(resultSet.getString("name"));
			user.setMobile(resultSet.getLong("mobile"));
			user.setDeptName(resultSet.getString("dept_name"));
			
			return user;
		}
	}
	
}
