package com.task.UserDashboard.repository;

import java.util.List;

import com.task.UserDashboard.dto.User;

public interface UserRepository {

	List<User> findAll();
	void save(User user);
}
