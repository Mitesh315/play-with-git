package com.task.UserDashboard.dto;

import java.time.LocalDateTime;

public class User {
	
	private long id;
	
	private String name;
	
	private long mobile;
	
	private String deptName;
	
	public User() {
		super();
	}
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getMobile() {
		return mobile;
	}

	public User(long id, String name, long mobile, String deptName) {
		super();
		this.id = id;
		this.name = name;
		this.mobile = mobile;
		this.deptName = deptName;
	}


	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	
}
