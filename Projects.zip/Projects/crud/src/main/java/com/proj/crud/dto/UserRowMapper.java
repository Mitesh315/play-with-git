package com.proj.crud.dto;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.proj.crud.model.User;

public class UserRowMapper implements RowMapper<User> {
	@Override
	public User mapRow(ResultSet resultSet, int rowNum) throws SQLException {
		User user = new User();
		user.setId(resultSet.getLong("id"));
		user.setName(resultSet.getString("name"));
		user.setMobile(resultSet.getLong("mobile"));
		user.setDept(resultSet.getString("dept"));
		
		return user;
	}
}


//@Override    
//public void updatePolicyMaster(Map<String, String> row) {       
//	String sql = "UPDATE policy_master SET insured_name = ?, mobile2 = ?, customer_address1 = ?, customer_address2 = ?, " +             
//"customer_address3 = ?, customer_city = ?, state = ?, customer_pincode = ?, product_name = ?, make = ?, " +             
//			"model = ?, fuel_type = ?, regi_no = ?, engine_no = ?, chassis_no = ?, model_variant = ?, age = ?, " +             
//"biztype = ?, policy_Number = ?, policy_end_date = ?, veh_idv = ?, regi_date = ?, rto_location = ?, " +             
//			"yom = ?, renewalpolicy_start_date = ?, lastyear_ncb = ? " +             
//"WHERE mobile1 = ? AND emailId = ?";       
//	try {          
//		jdbcTemplate.update(connection -> {             
//			PreparedStatement ps = connection.prepareStatement(sql);             
//			ps.setString(1, isEmpty(row.get("FirstName")) ? null : row.get("FirstName")); // insured_name             
//			ps.setString(2, isEmpty(row.get("MobilePhone2")) ? null : row.get("MobilePhone2")); // mobile2             
//			ps.setString(3, isEmpty(row.get("AddressLine1")) ? null : row.get("AddressLine1")); // customer_address1             
//			ps.setString(4, isEmpty(row.get("AddressLine2")) ? null : row.get("AddressLine2")); // customer_address2             
//			ps.setString(5, isEmpty(row.get("AddressLine3")) ? null : row.get("AddressLine3")); // customer_address3             
//			ps.setString(6, isEmpty(row.get("City")) ? null : row.get("City")); // customer_city             
//			ps.setString(7, isEmpty(row.get("State")) ? null : row.get("State")); // state             
//			ps.setObject(8, isEmpty(row.get("Pincode")) ? null : Integer.parseInt(row.get("Pincode"))); // customer_pincode             
//			ps.setString(9, isEmpty(row.get("ProductName")) ? null : row.get("ProductName")); // product_name             
//			ps.setString(10, isEmpty(row.get("VehicleMake")) ? null : row.get("VehicleMake")); // make             
//			ps.setString(11, isEmpty(row.get("VehicleModel")) ? null : row.get("VehicleModel")); // model             
//			ps.setString(12, isEmpty(row.get("FuelType")) ? null : row.get("FuelType")); // fuel_type             
//			ps.setString(13, isEmpty(row.get("RegistrationNo")) ? null : row.get("RegistrationNo")); // regi_no             
//			ps.setString(14, isEmpty(row.get("EngineNo")) ? null : row.get("EngineNo")); // engine_no             
//			ps.setString(15, isEmpty(row.get("ChassisNo")) ? null : row.get("ChassisNo")); // chassis_no             
//			ps.setString(16, isEmpty(row.get("VehicleVariant")) ? null : row.get("VehicleVariant")); // model_variant             
//			ps.setObject(17, isEmpty(row.get("VehicleAge")) ? 0 : Integer.parseInt(row.get("VehicleAge"))); // age             
//			ps.setString(18, isEmpty(row.get("BusinessType")) ? null : row.get("BusinessType")); // biztype             
//			ps.setString(19, isEmpty(row.get("PreviousPolicyNumber")) ? null : row.get("PreviousPolicyNumber")); // policy_Number             
//			ps.setString(20, isEmpty(row.get("PreviousPolicyEndDate")) ? null : row.get("PreviousPolicyEndDate")); // policy_end_date             
//			ps.setString(21, isEmpty(row.get("VehicleIDV")) ? null : row.get("VehicleIDV")); // veh_idv             
//			ps.setString(22, isEmpty(row.get("RegistrationDate")) ? null : row.get("RegistrationDate")); // regi_date             
//			ps.setString(23, isEmpty(row.get("RTO")) ? null : row.get("RTO")); // rto_location             
//			ps.setString(24, isEmpty(row.get("ManufacturingYear")) ? null : row.get("ManufacturingYear")); // yom             
//			ps.setString(25, isEmpty(row.get("NewPolicyPolicyStartDate")) ? null : row.get("NewPolicyPolicyStartDate")); // renewalpolicy_start_date             
//			ps.setString(26, isEmpty(row.get("PreviousYearNCB")) ? null : row.get("PreviousYearNCB")); // lastyear_ncb//           
//			ps.setString(27, String.valueOf(Instant.now().getEpochSecond())); // lead_id             
//			ps.setString(27, isEmpty(row.get("MobilePhone")) ? null : row.get("MobilePhone")); // WHERE mobile1             
//			ps.setString(28, isEmpty(row.get("Email")) ? null : row.get("Email")); // WHERE emailId             
//			return ps;          
//			});       
//		} catch (DataAccessException e) {          
//			throw new RuntimeException("Error updating policy_master: " + e.getMessage(), e);       
//			}    } 
//	}
//	}
//}