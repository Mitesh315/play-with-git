package com.proj.crud.dto;

public class UserDto {

}
