package com.proj.crud.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proj.crud.model.User;
import com.proj.crud.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	UserRepository userRepository;
	
	@Override
	public void saveUser(User user) {
		userRepository.saveUser(user);
	}

	@Override
	public List<User> getAllUser() {
		return userRepository.getAllUser();
	}

	@Override
	public void updateName(User user) {
		userRepository.updateName(user);
	}

	@Override
	public Optional<User> getById(long id) {
		return userRepository.getById(id);
	}

	@Override
	public void deleteUser(long id) {
		userRepository.deleteUser(id);
	}
	
	

}
