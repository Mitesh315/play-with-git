package com.proj.crud.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.proj.crud.model.User;
import com.proj.crud.service.UserService;

@RestController
@RequestMapping("/crud")
public class UserController {
	
	@Autowired
	UserService userService;
	
	@PostMapping("/add")
	public ResponseEntity<String> saveUser(@RequestBody User user) {
		try {
			userService.saveUser(user);
			return ResponseEntity.ok("user account created");
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	@GetMapping("/getAll")
	public List<User> getAllUsers() {
		try {
			return userService.getAllUser();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	@PostMapping("/updateName")
	public ResponseEntity<String> updateName(@RequestBody User user) {
		try {
			userService.updateName(user);
			return ResponseEntity.ok("Name updated sucessfully");
		}
		catch (Exception e) {
			throw new RuntimeException();
		}
	}
	
	@GetMapping("/getUser")
	public Optional<User> getById(@RequestParam long id) {
		try {
			return userService.getById(id);
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	@PostMapping("/deleteUser")
	public ResponseEntity<String> deleteUser(@RequestParam long id) {
		try {
			userService.deleteUser(id);
			return ResponseEntity.ok("User deleted successfully");
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	
}
