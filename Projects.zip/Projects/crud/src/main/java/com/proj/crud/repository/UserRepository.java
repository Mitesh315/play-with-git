package com.proj.crud.repository;

import java.util.List;
import java.util.Optional;

import com.proj.crud.model.User;


public interface UserRepository {
	
	void saveUser(User user);
	
	List<User> getAllUser();
	
	void updateName(User user);
	
	Optional<User> getById(long id);
	
	void deleteUser(long id);
}
