package com.proj.crud.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.proj.crud.dto.UserRowMapper;
import com.proj.crud.model.User;

@Repository
public class UserRepositoryImpl implements UserRepository{
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	

	@Override
	public void saveUser(User user) {
		String sql = "INSERT INTO user (id, name, mobile, dept) VALUES (?, ?, ?, ?)";
		jdbcTemplate.update(sql, user.getId(), user.getName(), user.getMobile(), user.getDept());
	}


	@Override
	public List<User> getAllUser() {
		String sql = "SELECT * FROM user";
		return jdbcTemplate.query(sql, new UserRowMapper());
	}


	@Override
	public void updateName(User user) {
		String sql = "UPDATE user SET name = ? where id = ?";
		jdbcTemplate.update(sql, user.getName(), user.getId());
	}


	@Override
	public Optional<User> getById(long id) {
		String sql = "SELECT * FROM user WHERE id = ?";
		return Optional.ofNullable(jdbcTemplate.queryForObject(sql, new UserRowMapper(), id));
	}


	@Override
	public void deleteUser(long id) {
		String sql = "DELETE FROM user WHERE id = ?";
		jdbcTemplate.update(sql, id);
		
	}
	
	
	
}
