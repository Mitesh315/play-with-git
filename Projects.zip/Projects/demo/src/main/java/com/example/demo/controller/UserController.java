package com.example.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.User;

@RestController
@RequestMapping("/crudapp")
public class UserController {
	
	@GetMapping("/user")
	public User getUserDetails(int id) {
		return new User(1, "Mitesh", "mitesh@gmail.com");
	}

}
