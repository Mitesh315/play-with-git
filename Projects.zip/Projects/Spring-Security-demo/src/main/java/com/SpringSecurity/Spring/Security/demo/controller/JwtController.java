package com.SpringSecurity.Spring.Security.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/demo")
public class JwtController {
	
//	@Autowired
//	private JwtUtil jwt;

//	@PostMapping("/authenticate")
//	public String authenticate(@RequestParam String username, @RequestParam String password) {
//		
//	}
	
	@GetMapping("/hello")
	public String hello() {
		return "hello";
	}
	
	@PreAuthorize("hasRole('USER')")
	@GetMapping("/user")
	public String userEndpoint() {
		return "Hello User!";
	}
	
	@PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/admin")
	public String adminEndpoint() {
		return "Hello Admin!";
	}
}
